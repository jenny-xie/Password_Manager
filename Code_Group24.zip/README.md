XGW_Password_Manager
How to run the program in an IDE:

Compile the program in a compiler
Run the executable
How to run the program in cmd:

Change directory to the source folder
Type "g++ -std=c++11 XGW-combined.cpp -o password_manager" to run the program
Run the executable